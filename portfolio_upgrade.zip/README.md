# Portfolio (Stiliyan Georgiev)

This project contains a Spring Boot + Thymeleaf portfolio web app.

Folders:
- templates/ -> Thymeleaf templates (home.html, projects.html)
- src/main/resources/static/css/style.css -> styles
- src/main/resources/static/img/projects/ -> generated thumbnails
- src/main/resources/static/files/ -> CVs (English + German)

Run locally (Linux/macOS):
1. mvnw clean package
2. mvnw spring-boot:run
Open http://localhost:8080

Java files are under:
src/main/java/com/example/portfolio/HomeController.java
src/main/java/com/example/portfolio/Project.java
