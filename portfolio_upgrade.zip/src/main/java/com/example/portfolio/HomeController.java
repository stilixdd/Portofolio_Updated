package com.example.portfolio;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("cvUpdated", "October 2025");
        model.addAttribute("aboutMeEng",
            "I am a motivated and ambitious Computer Science student with strong interests in game development and software engineering. " +
            "Currently studying Business Information Technology at TH Köln, with previous experience in Games Engineering at TUM. " +
            "I am seeking opportunities to apply my programming knowledge in real-world IT environments and continue developing my skills.");
        model.addAttribute("aboutMeGer",
            "Ich bin ein motivierter und ehrgeiziger Informatikstudent mit großem Interesse an Spieleentwicklung und Software Engineering. " +
            "Derzeit studiere ich Wirtschaftsinformatik an der TH Köln und habe zuvor Games Engineering an der TU München studiert. " +
            "Ich suche nach Möglichkeiten, meine Programmierkenntnisse praktisch einzusetzen und meine Fähigkeiten weiterzuentwickeln.");
        return "home";
    }

    @GetMapping("/projects")
    public String projects(Model model) {
        List<Project> projectList = List.of(
            new Project("Space Shooter Game",
                "Developed a 2D space shooter with enemy AI and level system.",
                List.of("Java", "LibGDX", "Game Development"),
                "https://github.com/stilixdd/Spaceshooter",
                "/img/projects/spaceshootergame-thumb.jpg"),
            new Project("Space Shooter - Playable Demo",
                "WebGL build of the Space Shooter playable in browser.",
                List.of("Unity", "C#", "WebGL"),
                "https://stilixdd.itch.io/spaceshooter",
                "/img/projects/spaceshooterdemo-thumb.jpg"),
            new Project("Shooting Game (Prototype)",
                "Prototype of a first-person shooter focused on gameplay mechanics.",
                List.of("Java", "OpenGL", "Game Development"),
                "#",
                "/img/projects/shootinggame-thumb.jpg"),
            new Project("Fornelli.de Website",
                "Built a responsive company website using WordPress; optimized SEO and performance.",
                List.of("HTML", "CSS", "JavaScript", "WordPress"),
                "https://www.fornelli.de/",
                "/img/projects/fornelli-thumb.jpg"),
            new Project("Task Manager App",
                "A CRUD web app for managing tasks with MySQL backend.",
                List.of("Java", "Spring MVC", "MySQL"),
                "#",
                "/img/projects/taskmanager-thumb.jpg")
        );

        model.addAttribute("projects", projectList);
        return "projects";
    }
}
